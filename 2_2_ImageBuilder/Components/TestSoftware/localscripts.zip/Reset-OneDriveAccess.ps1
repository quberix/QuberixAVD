Write-Host ""
Write-host "OneDrive RESET - PLEASE READ CAREFULLY" -fore Red
Write-Host ""
Write-Host "This script resets your access to OneDrive." 
Write-Host "The script will delete your OneDrive synchronisation folder in your profile."
Write-Host "When you next log in, you will be forced to sign back in to OneDrive and any synchronisation you had previously will be lost."
Write-Host "This DOES NOT delete any content already within OneDrive, only how it is synchronised to this system"
Write-Host ""

$folderOneDrive = "~\AppData\Local\OneDrive"
$folderMSOneDrive = "~\AppData\Local\Microsoft\OneDrive\settings"
$folderMSOneAuth = "~\AppData\Local\Microsoft\OneAuth"

$result = Read-Host "Do you wish to continue? (Type: yes, to continue)"
if ($result -match '[Yy][Ee][Ss]') {
    Write-Host ""
    Write-Host "Stopping OneDrive - Please ignore any errors"
    Stop-Process -Name "OneDrive" -ErrorAction SilentlyContinue
    Start-Sleep 5
    Write-Host ""
    Write-Host "Resetting OneDrive"
    
    if (Test-Path -Path $folderOneDrive) {
        Remove-Item $folderOneDrive -Recurse -Force
    }

    if (Test-Path -Path $folderMSOneDrive) {
        Remove-Item $folderMSOneDrive -Force -Recurse
    }

    if (Test-Path -Path $folderMSOneAuth) {
        Remove-Item $folderMSOneAuth -Force -Recurse
    }
    
    Write-Host "OneDrive Reset complete.  Restarting OneDrive."
    Start-Process "C:\Program Files\Microsoft OneDrive\OneDrive.exe"
    Write-Host ""
    Read-Host "Work Complete.  Press any key to close this window"

} else {
    Write-Host ""
    Write-Host "OneDrive Reset CANCELLED"
    Write-Host ""
}